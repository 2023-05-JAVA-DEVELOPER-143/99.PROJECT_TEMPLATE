function callNumber(num){
	location.href="tel:"+num;
}